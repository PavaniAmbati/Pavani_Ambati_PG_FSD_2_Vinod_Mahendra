package com.simplilearn.workshop.model;

import javax.persistence.Entity;

@Entity
public class SourceCity {
	
	private int source_id;
	private String city;
	
	public SourceCity() {
		super();
	}

	public int getSource_id() {
		return source_id;
	}

	public void setSource_id(int source_id) {
		this.source_id = source_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	
}
